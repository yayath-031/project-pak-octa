# __init__.py

from .komik import cari_komik
from .film import cari_film
from .lagu import cari_lagu
from .game import cari_game
from .novel import cari_novel
from .series import cari_series