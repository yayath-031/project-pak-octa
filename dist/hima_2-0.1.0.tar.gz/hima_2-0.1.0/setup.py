from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name='hima.2',  # Ganti dengan nama yang sesuai
    version='0.1.0',
    description='Mencari referensi dengan cepat',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yayath-031/project-pak-octa.git',  # Ganti dengan URL yang benar
    author='Kiyowo Team',
    author_email='yaynature01@gmail.com',
    license='MIT',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    keywords='film, reference, series, movie, comic, song, game, novel',
    packages=find_packages(),
    install_requires=[],  # Tambahkan jika ada dependensi lain
    python_requires='>=3.6',  # Sesuaikan dengan versi Python
)
